console.log("meow");
////opts = {

////    include_css: true   // Include aditional css stylesheets in the Cache
////};

////var cachep2p = new CacheP2P(opts);
//var cachep2p = new CacheSolution();
//cachep2p.on('ready', function () {
//    console.log('This page has been cached!')
//});


//cachep2p.on('cache', function (event) { console.log("cache"); });

//cachep2p.on('message' | 'alert' | 'popstate', function (message) {
//    console.log(message);
//});

//cachep2p.on('webtorrent', function (message) {
//    console.log(message);
//});

//cachep2p.on('success', function (message) {
//    console.log(message);
//});